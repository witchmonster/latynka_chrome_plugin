# Ukrajins'ka latynka Translator
Uses the algorythm from jkramr/latynka to translate pages.

Chrome Store link: https://chrome.google.com/webstore/detail/ukrajinska-latynka-transl/dflniejibinlfcafclbjfdjlcpgkkfhe?hl=en-GB&authuser=0
